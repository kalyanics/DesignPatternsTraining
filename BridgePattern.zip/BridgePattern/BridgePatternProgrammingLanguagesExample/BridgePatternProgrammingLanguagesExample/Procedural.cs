﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProgrammingLanguages
{
    class Procedural : IProgrammingParadigm
    {
        public string GetParadigm()
        {
            return "Procedural";
        }

        public string GetUnit()
        {
            throw new NotImplementedException();
        }
    }
}
