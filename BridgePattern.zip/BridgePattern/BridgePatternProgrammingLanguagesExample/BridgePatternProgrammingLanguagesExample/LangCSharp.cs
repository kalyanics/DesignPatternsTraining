﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProgrammingLanguages
{
    class LangCSharp : IProgrammingLanguage
    {
        public IProgrammingParadigm reference;
        public string GetName()
        {
            return "C Sharp";
        }
    }
}
