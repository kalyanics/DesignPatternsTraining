﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProgrammingLanguages
{
    class LangC : IProgrammingLanguage
    {
        public IProgrammingParadigm reference;
        public string GetName()
        {
            return "C";
        }
    }
}
