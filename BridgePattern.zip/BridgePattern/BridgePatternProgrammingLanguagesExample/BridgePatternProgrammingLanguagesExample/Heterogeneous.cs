﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProgrammingLanguages
{
    class Heterogeneous : IProgrammingParadigm
    {
        List<IProgrammingParadigm> paradigms = new List<IProgrammingParadigm>();
        public string GetParadigm()
        {
            throw new NotImplementedException();
        }

        public string GetUnit()
        {
            throw new NotImplementedException();
        }

        public void AddParadigm(IProgrammingParadigm paradigm)
        {
            paradigms.Add(paradigm);
        }

        public void RemoveParadigm(IProgrammingParadigm paradigm)
        {
            paradigms.Remove(paradigm)
        }
    }
}
