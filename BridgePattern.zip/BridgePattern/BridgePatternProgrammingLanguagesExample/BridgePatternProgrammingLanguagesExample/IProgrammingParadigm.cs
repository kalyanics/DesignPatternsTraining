﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProgrammingLanguages
{
    interface IProgrammingParadigm
    {
        public string GetUnit();
        public string GetParadigm();
    }
}
