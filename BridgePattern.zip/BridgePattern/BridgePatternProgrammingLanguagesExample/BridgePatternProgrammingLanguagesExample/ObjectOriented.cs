﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProgrammingLanguages
{
    class ObjectOriented : IProgrammingParadigm
    {
        public string GetParadigm()
        {
            return "Object Oriented";
        }

        public string GetUnit()
        {
            throw new NotImplementedException();
        }
    }
}
