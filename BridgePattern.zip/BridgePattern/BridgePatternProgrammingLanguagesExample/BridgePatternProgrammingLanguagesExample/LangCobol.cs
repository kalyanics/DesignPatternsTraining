﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProgrammingLanguages
{
    class LangCobol : IProgrammingLanguage
    {
        public IProgrammingParadigm reference;
        public string GetName()
        {
            return "Cobol";
        }
    }
}
