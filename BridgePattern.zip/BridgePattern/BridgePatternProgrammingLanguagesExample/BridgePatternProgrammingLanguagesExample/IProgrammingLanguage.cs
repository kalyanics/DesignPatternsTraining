﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProgrammingLanguages
{
    interface IProgrammingLanguage
    {
        public string GetName();
    }
}
