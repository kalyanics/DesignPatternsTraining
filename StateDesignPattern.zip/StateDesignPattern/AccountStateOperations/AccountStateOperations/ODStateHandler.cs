﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountStateOperations
{
    class ODStateHandler : IAccountStateHandler
    {
        public void withdraw(Account context, int amount)
        {
            if(amount <= context.ODLimit)
            {
                context.OD -= amount;
            }
            else
            {
                Console.WriteLine("The withdrawl amount is greater than the OD limit");
            }
            if(context.OD == 0)
            {
                context.setState(new SuspendedStateHandler());
            }
        }

        public void deposit(Account context, int amount)
        {
            context.balance = amount - context.ODLimit + context.OD;

            context.OD = context.ODLimit;
            
            context.setState(new ActiveStateHandler());
        }
    }
}
