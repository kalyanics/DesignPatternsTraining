﻿using System;

namespace AccountStateOperations
{
    class Program
    {
        static void Main(string[] args)
        {
            //Console.WriteLine("Hello World!");


            Account myAccount = new Account();
            myAccount.ODLimit = 1000;
            myAccount.setState(new ActiveStateHandler());
            myAccount.deposit(5000);
            Console.WriteLine("Account is in " + myAccount.state + "state and the balance is " + myAccount.balance);
            myAccount.withdraw(2000);
            Console.WriteLine("Account is in " + myAccount.state + "state and the balance is " + myAccount.balance);
            myAccount.OD = 1000;
            myAccount.withdraw(3000);
            Console.WriteLine("Account is in " + myAccount.state + "state and the balance is " + myAccount.balance);
            myAccount.withdraw(900);
            Console.WriteLine("Account is in " + myAccount.state + "state and the balance is " + myAccount.balance);
            myAccount.deposit(1500);
            Console.WriteLine("Account is in " + myAccount.state + "state and the balance is " + myAccount.balance);
        }
    }
}
