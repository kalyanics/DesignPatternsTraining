﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountStateOperations
{
    class Account
    {
        public IAccountStateHandler state;
        public int balance;
        public int OD;
        public int ODLimit;
        public void withdraw(int amount)
        {
            state.withdraw(this, amount);
        }
        public void deposit(int amount)
        {
            state.deposit(this, amount);
        }
        public void setState(IAccountStateHandler newState)
        {
            state = newState;
        }
    }
}
