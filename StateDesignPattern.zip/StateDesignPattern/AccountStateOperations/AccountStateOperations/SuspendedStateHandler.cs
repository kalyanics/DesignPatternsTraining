﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountStateOperations
{
    class SuspendedStateHandler : IAccountStateHandler
    {
        public void withdraw(Account context, int amount)
        {
            context.balance -= amount;
            Console.WriteLine("Withdraw operation not possible on a suspended account\n");
        }

        public void deposit(Account context, int amount)
        {
            context.balance += amount;
            context.setState(new ActiveStateHandler());
        }
    }
}
