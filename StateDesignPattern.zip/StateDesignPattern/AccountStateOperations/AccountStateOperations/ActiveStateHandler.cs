﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountStateOperations
{
    class ActiveStateHandler:IAccountStateHandler
    {
        public void withdraw(Account context, int amount)
        {
            if (amount <= context.balance)
            {
                context.balance -= amount;
            }
            if(context.balance == 0)
            {
                context.setState(new ODStateHandler());
            }
        }

        public void deposit(Account context, int amount)
        {
            context.balance += amount;
        }
    }
}
