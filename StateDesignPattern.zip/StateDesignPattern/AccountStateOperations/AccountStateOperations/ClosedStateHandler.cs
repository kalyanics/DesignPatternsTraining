﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountStateOperations
{
    class ClosedStateHandler : IAccountStateHandler
    {
        public void withdraw(Account context, int amount)
        {
            Console.WriteLine("Withdraw operation not possible on a closed account\n");
        }

        public void deposit(Account context, int amount)
        {
            Console.WriteLine("Deposit operation not possible on a closed account\n");
        }
    }
}
