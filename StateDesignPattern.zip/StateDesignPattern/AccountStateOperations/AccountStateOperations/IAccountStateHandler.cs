﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AccountStateOperations
{
    interface IAccountStateHandler
    {
        public void withdraw(Account context, int amount);
        public void deposit(Account context, int amount);
    }
}
