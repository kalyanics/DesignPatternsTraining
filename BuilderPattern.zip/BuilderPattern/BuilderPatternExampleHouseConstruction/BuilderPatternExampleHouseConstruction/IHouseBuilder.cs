﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuilderPatternExampleHouseConstruction
{
    interface IHouseBuilder
    {
        public void BuildBasement();
        public void BuildStructure();
        public void BuildRoof();
        public void BuildInteriors();
        public House GetHouse();
        public void SetHouse(House house);

    }
}
