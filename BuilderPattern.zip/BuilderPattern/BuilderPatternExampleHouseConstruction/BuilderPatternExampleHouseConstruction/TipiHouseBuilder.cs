﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuilderPatternExampleHouseConstruction
{
    class TipiHouseBuilder : IHouseBuilder
    {
        House house;
        public void setHouse(House house)
        {
            this.house = house;
        }

        public void BuildBasement()
        {
            house.SetBasement("Wood");
        }

        public void BuildInteriors()
        {
            house.SetInteriors("wood");
        }

        public void BuildRoof()
        {
            house.SetRoof("Wood");
        }

        public void BuildStructure()
        {
            house.SetStructure("Wood");
        }

        public House GetHouse()
        {
            return this.house;
        }

        public void SetHouse(House house)
        {
            this.house = house;
        }
    }
}
