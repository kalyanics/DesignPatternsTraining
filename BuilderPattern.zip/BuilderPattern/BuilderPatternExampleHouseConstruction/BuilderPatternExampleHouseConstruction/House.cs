﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuilderPatternExampleHouseConstruction
{
    class House
    {
        public string structure;
        public string roof;
        public string basement;
        public string interiors;
        
        public void SetInteriors(string interiors)
        {
            this.interiors = interiors;
        }

        public void SetStructure(string structure)
        {
            this.structure = structure;
        }

        public void SetBasement(string basement)
        {
            this.basement = basement;
        }

        public void SetRoof(string roof)
        {
            this.roof = roof;
        }


    }
}
