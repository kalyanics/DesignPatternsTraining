﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuilderPatternExampleHouseConstruction
{
    class IglooHouseBuilder : IHouseBuilder
    {
        House house;

        string material = "Ice";
        public void setHouse(House house)
        {
            this.house = house;
        }

        public void BuildBasement()
        {
            house.SetBasement(material);
        }

        public void BuildInteriors()
        {
            house.SetInteriors("Ice");
        }

        public void BuildRoof()
        {
            house.SetRoof("Ice");
        }

        public void BuildStructure()
        {
            house.SetStructure("Ice");
        }

        public House GetHouse()
        {
            return this.house;
        }

        public void SetHouse(House house)
        {
            this.house = house;
        }
    }
}
