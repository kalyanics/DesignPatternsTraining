﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BuilderPatternExampleHouseConstruction
{
    class CivilEngineer
    {
        IHouseBuilder houseBuilder;
        public void SetHouseBuilder(IHouseBuilder houseBuilder)
        {
            this.houseBuilder = houseBuilder;
        }
        public House ConstructHouse()
        {

            this.houseBuilder.BuildBasement();
            this.houseBuilder.BuildStructure();
            this.houseBuilder.BuildRoof();
            this.houseBuilder.BuildInteriors();
            return this.houseBuilder.GetHouse();
        }
    }
}
