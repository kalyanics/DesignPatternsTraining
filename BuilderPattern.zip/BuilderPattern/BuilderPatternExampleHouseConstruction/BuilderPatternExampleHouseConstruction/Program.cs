﻿using System;

namespace BuilderPatternExampleHouseConstruction
{
    class HouseConstruction
    {
        static void Main(string[] args)
        {
            CivilEngineer civilEngineer = new CivilEngineer();
            IHouseBuilder houseBuilder = new IglooHouseBuilder();
            houseBuilder.SetHouse(new House());
            civilEngineer.SetHouseBuilder(houseBuilder);
            House house = civilEngineer.ConstructHouse();
            Console.WriteLine("House details : basement is " + house.basement + ", structure is " + house.structure + ", roof is " + house.roof + " and the interiors made of " + house.interiors);
        }
    }
}
