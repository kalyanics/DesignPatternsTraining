﻿namespace PrototypePatternSandwichPrototype
{
    abstract class SandwichPrototype
    {
        public abstract SandwichPrototype Clone();
    }
}
