﻿using System.Collections.Generic;

namespace PrototypePatternSandwichPrototype
{
    class Sandwich : SandwichPrototype
    {
        private string bread;
        private string meat;
        private string cheese;
        private List<string> veggies;

        public Sandwich(string bread, string meat, string cheese, List<string> veggies)
        {
            this.bread = bread;
            this.meat = meat;
            this.cheese = cheese;
            this.veggies = veggies;
        }

        public override SandwichPrototype Clone()
        {
            return MemberwiseClone() as SandwichPrototype;
        }

    }
}
