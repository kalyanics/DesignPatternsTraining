﻿using System.Collections.Generic;

namespace PrototypePatternSandwichPrototype
{
    class Program
    {
        static void Main(string[] args)
        {
            SandwichMenu sandwichMenu = new SandwichMenu();

            // Initialize with default sandwiches
            sandwichMenu["BLT"]
                = new Sandwich("Wheat", "Bacon", "", new List<string>() { "Lettuce, Tomato" });
            sandwichMenu["Vegetarian"]
                = new Sandwich("Wheat", "", "", new List<string>() { "Lettuce, Onion, Tomato, Olives, Spinach" });


            // Now we can clone these sandwiches
            Sandwich sandwich1 = sandwichMenu["BLT"].Clone() as Sandwich;
            Sandwich sandwich2 = sandwichMenu["Vegetarian"].Clone() as Sandwich;
        }
    }
}
