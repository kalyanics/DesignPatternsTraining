﻿namespace MementoPatternExampleSalesProspect
{
    class Program
    {
        static void Main(string[] args)
        {
            SalesProspect salesProspect = new SalesProspect();
            salesProspect.Name = "Ram";
            salesProspect.Phone = "9123456789";
            salesProspect.Budget = 25000.0;
            // Store internal state
            ProspectMemory m = new ProspectMemory();
            m.Memento = salesProspect.SaveMemento();
            // Continue changing originator
            salesProspect.Name = "Sham";
            salesProspect.Phone = "9876543210";
            salesProspect.Budget = 1000000.0;
            // Restore saved state
            salesProspect.RestoreMemento(m.Memento);
        }
    }
}
