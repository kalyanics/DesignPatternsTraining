﻿using System;
using System.Net;

namespace ProxyPatternExamplePICGateWayProxy
{
    class Browser
    {
        public IInternetGateWayController gateWay;

        public void UpdateAddressBarUrl(Uri uri)
        {
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(uri.AbsoluteUri);
            HttpWebResponse response = gateWay.Accept(request);
            Console.WriteLine(response);
        }
    }
}
