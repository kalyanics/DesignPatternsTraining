﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace ProxyPatternExamplePICGateWayProxy
{
    class PICInternetGatWayProxy : IInternetGateWayController
    {
        List<Uri> whiteListedUrls = new List<Uri>{ new Uri("https://intranet.philips.com"), new Uri("https://intranet.philips.com"), new Uri("https://intranet.philips.com") };
        PICInternetGateWay PICGateway = new PICInternetGateWay();
        public HttpWebResponse Accept(HttpWebRequest request)
        {
            if (whiteListedUrls.Contains(request.RequestUri))
            {
                return PICGateway.Accept(request);
            }
            else
            {
                throw new Exception("Url not accessible as the proxy blocks the same");
            }
        }
    }
}
