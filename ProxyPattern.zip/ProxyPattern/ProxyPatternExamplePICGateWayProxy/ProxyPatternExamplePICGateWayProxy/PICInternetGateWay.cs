﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace ProxyPatternExamplePICGateWayProxy
{
    class PICInternetGateWay : IInternetGateWayController
    {
        public HttpWebResponse Accept(HttpWebRequest request)
        {
            HttpWebResponse response =  new HttpWebResponse();
            return response;
        }
    }
}
