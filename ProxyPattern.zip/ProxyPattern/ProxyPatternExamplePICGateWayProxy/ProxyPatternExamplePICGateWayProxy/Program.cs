﻿using System;

namespace ProxyPatternExamplePICGateWayProxy
{
    class Program
    {
        static void Main(string[] args)
        {
            Browser chrome = new Browser();
            IInternetGateWayController internetGateWay = new PICInternetGatWayProxy();
            chrome.gateWay = internetGateWay;
            chrome.UpdateAddressBarUrl(new Uri("https://intranet.philips.com"));
        }
    }
}
