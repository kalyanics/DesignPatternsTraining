﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryPatternExamplePlans
{
    abstract class Plan
    {
        protected double rate;

        public abstract double getRate();
    }
}
