﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryPatternExamplePlans
{
    class CommercialPlan : Plan
    {
        public override double getRate()
        {
            rate = 7.5;
            return rate;
        }
    }
}
