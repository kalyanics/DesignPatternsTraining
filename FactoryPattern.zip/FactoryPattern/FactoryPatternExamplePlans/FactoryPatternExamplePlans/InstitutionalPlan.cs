﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryPatternExamplePlans
{
    class InstitutionalPlan : Plan
    {
        public override double getRate()
        {
            rate = 5.5;
            return rate;
        }
    }
}
