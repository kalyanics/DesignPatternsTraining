﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryPatternExamplePlans
{
    class DomesticPlan : Plan
    {
        public override double getRate()
        {
            rate = 3.5;
            return rate;
        }
    }
}
