﻿using System;

namespace FactoryPatternExamplePlans
{
    class GenerateBill
    {
        static void Main(string[] args)
        {
            PlanFactory planFactory = new PlanFactory();

            Plan plan = planFactory.getPlan("DOMESTICPLAN");

            Console.WriteLine("The rate of interest is : " + plan.getRate());
        }
    }
}
