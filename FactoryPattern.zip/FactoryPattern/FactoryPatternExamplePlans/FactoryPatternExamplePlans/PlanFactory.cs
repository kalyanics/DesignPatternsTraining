﻿using System;
using System.Collections.Generic;
using System.Text;

namespace FactoryPatternExamplePlans
{
    class PlanFactory
    {
        public Plan getPlan(string planType)
        {
            if (planType == null)
            {
                return null;
            }
            if (planType=="DOMESTICPLAN")
            {
                return new DomesticPlan();
            }
            else if (planType=="COMMERCIALPLAN")
            {
                return new CommercialPlan();
            }
            else if (planType=="INSTITUTIONALPLAN")
            {
                return new InstitutionalPlan();
            }
            return null;
        } 
    }
}
