﻿using System;
using System.Collections.Generic;

namespace VisitorPatternExampleDocumentPart
{
    class Program
    {
        static void Main(string[] args)
        {
            PICDocument picDocument = new PICDocument();
            PICDocumentConverter converter = new HtmlDocumentConverter();
            picDocument.addPart(new Paragraph());
            picDocument.addPart(new Header());
            picDocument.addPart(new Link());
            picDocument.open();
            picDocument.close();
            picDocument.dispose();
            List<string> convertedHtmlString = picDocument.convert(converter);
        }
    }
}
