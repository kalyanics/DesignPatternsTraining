﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VisitorPatternExampleDocumentPart
{
    class Link : DocumentPart
    {
        public string url;
        public string linkText;
        public override void open() { }
        public override void close() { }
        public override void dispose() { }
        public override string convert(PICDocumentConverter converter)
        {
            string htmlString = converter.convert(this);
            return htmlString;
        }
    }
}
