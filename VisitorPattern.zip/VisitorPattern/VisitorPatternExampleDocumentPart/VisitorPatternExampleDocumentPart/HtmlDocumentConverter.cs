﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VisitorPatternExampleDocumentPart
{
    class HtmlDocumentConverter : PICDocumentConverter
    {
        public override string convert(Paragraph paragraph)
        {
            string htmlString = "<p>" + paragraph.content + "</p>";
            return htmlString;
        }

        public override string convert(Link link)
        {
            string htmlString = "<a href=" + "'" + link.url + "'" + ">" + link.linkText + "</a>";
            return htmlString;
        }

        public override string convert(Header header)
        {
            string htmlString = "<h>" + header.title + "</h>";
            return htmlString;
        }
    }
}
