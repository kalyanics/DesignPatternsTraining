﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VisitorPatternExampleDocumentPart
{
    class Header : DocumentPart
    {
        public string title;
        public override void open() { }
        public override void close() { }
        public override void dispose() { }

        public override string convert(PICDocumentConverter converter)
        {
            string htmlString = converter.convert(this);
            return htmlString;
        }
    }
}
