﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VisitorPatternExampleDocumentPart
{
    abstract class PICDocumentConverter
    {
        public abstract string convert(Paragraph paragraph);
        public abstract string convert(Link link);
        public abstract string convert(Header header);
    }
}
