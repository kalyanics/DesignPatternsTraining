﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VisitorPatternExampleDocumentPart
{
    class PICDocument
    {
        public List<DocumentPart> documentParts = new List<DocumentPart>();
        public void addPart(DocumentPart documentPart)
        {
            documentParts.Add(documentPart);
        }

        public void RemovePart(DocumentPart documentPart)
        {
            documentParts.Remove(documentPart);
        }
        public void open()
        {
            foreach(DocumentPart documentPart in documentParts)
            {
                documentPart.open();
            }
        }

        public void close()
        {
            foreach (DocumentPart documentPart in documentParts)
            {
                documentPart.close();
            }
        }

        public void dispose()
        {
            foreach (DocumentPart documentPart in documentParts)
            {
                documentPart.dispose();
            }
        }

        public List<string> convert(PICDocumentConverter converter)
        {
            List<string> listOfHtmlStrings = new List<string>();
            foreach (DocumentPart documentPart in documentParts)
            {
                listOfHtmlStrings.Add(documentPart.convert(converter));
            }
            return listOfHtmlStrings;
        }
    }
}
