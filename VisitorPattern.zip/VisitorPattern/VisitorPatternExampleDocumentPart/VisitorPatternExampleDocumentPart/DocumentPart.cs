﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VisitorPatternExampleDocumentPart
{
    abstract class DocumentPart
    {
        public abstract void open();
        public abstract void close();
        public abstract void dispose();
        public abstract string convert(PICDocumentConverter converter); 
    }
}