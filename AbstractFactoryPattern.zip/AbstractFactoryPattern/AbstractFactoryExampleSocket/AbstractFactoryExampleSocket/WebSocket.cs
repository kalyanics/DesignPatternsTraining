﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    class WebSocket : ISocket
    {
        public void close()
        {
            Console.WriteLine("WebSocket closed");
        }

        public void disconnect()
        {
            Console.WriteLine("WebSocket disconnected");
        }

        public void open()
        {
            Console.WriteLine("WebSocket openend");
        }
    }
}
