﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    interface ISocket
    {
        public void open();
        public void close();
        public void disconnect();
    }
}
