﻿using System;

namespace AbstractFactoryPattern
{
    class Program
    {
        static void Main(string[] args)
        {
            ISocket socketRef;
            ISocketFactory socketFactoryRef = new HttpSocketFactory();
            socketRef = socketFactoryRef.CreateSocket();
            socketRef.open();
            socketRef.close();
            socketRef.disconnect();
        }
    }
}
