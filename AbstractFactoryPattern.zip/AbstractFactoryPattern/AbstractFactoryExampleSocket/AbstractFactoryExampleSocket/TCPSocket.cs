﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    class TCPSocket:ISocket
    {
        public void close()
        {
            Console.WriteLine("TCP closed");
        }

        public void disconnect()
        {
            Console.WriteLine("TCP disconnected");
        }

        public void open()
        {
            Console.WriteLine("TCP openend");
        }
    }
}
