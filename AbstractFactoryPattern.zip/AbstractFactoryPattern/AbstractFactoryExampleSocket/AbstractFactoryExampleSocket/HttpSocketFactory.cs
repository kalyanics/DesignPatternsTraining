﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    class HttpSocketFactory : ISocketFactory
    {
        public ISocket CreateSocket()
        {
            ISocket socket = new HttpSocket();
            return socket;
        }
    }
}
