﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    class TCPSocketFactory : ISocketFactory
    {
        public ISocket CreateSocket()
        {
            ISocket socket = new TCPSocket();
            return socket;
        }
    }
}
