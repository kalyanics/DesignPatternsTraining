﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    class WebSocketFactory : ISocketFactory
    {
        public ISocket CreateSocket()
        {
            ISocket socket = new WebSocket();
            return socket;
        }
    }
}
