﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AbstractFactoryPattern
{
    class HttpSocket:ISocket
    {
        public void close()
        {
            Console.WriteLine("Httpsocket closed");
        }

        public void disconnect()
        {
            Console.WriteLine("Httpsocket disconnected");
        }

        public void open()
        {
            Console.WriteLine("Httpsocket openend");
        }
    }
}
